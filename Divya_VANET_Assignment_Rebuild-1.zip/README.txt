README - VANET Secure Routing Protocol Simulation

Author: Divya Singh
Email: divyasingh.divz@gmail.com

How to Run:
1. Ensure Python 3 is installed on your system.
2. Install required libraries using:
   pip install matplotlib pandas

3. Run the simulation:
   python main_simulation.py

This will display:
- Vehicle movement and hash validation
- Detection of tampered messages
- Hash function timing comparison
- Vehicle speed and position tracking

Files included:
- main_simulation.py: Python simulation
- VANET_Assignment_Report.docx: Project report
